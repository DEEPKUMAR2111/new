import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  reg='https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/register';
  log='https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/login';
  url='http://localhost:3000/user';
  
  constructor( private http:HttpClient) {  }

  errorHandel(error:HttpErrorResponse){  
    return throwError(error.message || 'server Error');
  }

  createPost(post: any){
    return this.http.post(this.reg,post).pipe(catchError(this.errorHandel));
    }

    getId(post:any){
      return this.http.post(this.log,post).pipe(catchError(this.errorHandel));
    }

    isLogin(){
      return localStorage.getItem("arr")!=null;
     }
     getPost(){
      return this.http.get(this.url).pipe(catchError(this.errorHandel));
      
    }
    // updatePost(post:any){
    //   return this.http.patch(this.url+'/'+post.id,post)
    //   }
    deletePost(post:any){
 
      return this.http.delete(this.url+'/'+post.id,post).pipe(catchError(this.errorHandel));
     }
     updatePost(post:any){
      return this.http.patch(this.url+'/'+post.id,post)
      }
    
     update(post:any,newData: any){
    
      return this.http.put(this.url+'/'+post.id,newData).pipe(catchError(this.errorHandel));
     }

     

}