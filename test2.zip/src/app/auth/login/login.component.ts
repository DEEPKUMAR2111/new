import { Router } from '@angular/router';

import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/services/service.service';
import { last } from 'rxjs';




@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  userData: any;
  constructor(private router:Router,private service:ServiceService){
    console.log("hello");
    localStorage.clear();
   }

   login= new FormGroup({ 
    email : new FormControl('',[Validators.required,Validators.email]),
    password :new FormControl('',[Validators.required,Validators.minLength(8)]),
  });
  get email(){
    return this.login.get('email');
  }
  get password(){
    return this.login.get('password');
  }

  submit(data:any){
    console.log(data);
    
    var storage:any
    if(this.login.valid){
      this.service.getId(data).subscribe(res=>{
        this.userData=res;
        var token=this.userData.data.access_token
        console.warn(token); 
     var first= this.userData.data.data.first_name; 
     var last= this.userData.data.data.last_name; 
       storage= JSON.stringify(this.userData.data.data);
        localStorage.setItem("arr",storage);
      localStorage.setItem("token",token);
      localStorage.setItem("first_name",first);
      localStorage.setItem("last_name",last);
       
       this.router.navigate(['/dashboard']);
        }, (error:Response)=>{
        
         var errorName="Can't Find This User.";
       
        console.log('404 Not Found',errorName);
      });
      
    }}
  
  goTo(){
    this.router.navigate(['auth/register'])
  }
}
  
