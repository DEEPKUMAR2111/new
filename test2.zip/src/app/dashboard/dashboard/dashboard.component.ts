import { Component } from '@angular/core';
import { ServiceService } from 'src/app/services/service.service';
import {NgxPaginationModule} from 'ngx-pagination';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {
p:any
 first:any
 last:any
 activeError=false;
 email="";

  constructor(private service:ServiceService){
   
     this.first=localStorage.getItem('first_name');
     this.last=localStorage.getItem('last_name');
    console.warn(this.first);
  }
 
  err="";
  posts: any;
  currentId:any;


  ngOnInit() {
    this.service.getPost().toPromise().then(data =>{ 
      this.posts = data ;
    },error=>{
      this.activeError=true;
       this.err="Unexpected Error :404 Not Found";
      console.log('404 Not Found');
    });
  }

  updatePost(post:any){
    this.service.updatePost(post)
    .toPromise().then(data=>{
      // console.log(data);
      let index=this.posts.indexOf(post);
    this.currentId=data;
    // this.form.setValue(this.currentId)
    // console.log(data);
    // data="";
  })
  }
  
    // createPost(post: any){
     
    //   this.service.createPost(post).toPromise().then(data=>{
    //       post=data;
    //       this.posts.splice(this.posts.length,0,post);
    //       console.log(data);    
    //     },
    //     (error:Response)=>{
    //       // this.activeError=true;
    //        var errorName="Can't Add This Item.";
    //        alert(errorName);
    //       console.log('404 Not Found');
    //     }
        
        // );  
    // }

    // updatePost(post:any){
    //   this.service.updatePost(post)
    //   .toPromise().then(data=>{
    //     // console.log(data);
    //     let index=this.posts.indexOf(post);
    //   this.currentId=data;
      // this.form.setValue(this.currentId)
      // console.log(data);
      // data="";
    // })
    

    deletePost(post:any){
      this.service.deletePost(post).toPromise().then(data=>{
        let index=this.posts.indexOf(post);
        console.log(index);
        this.posts.splice(index,1);
        console.log(data);
    },
    (error:Response)=>{
      // this.activeError=true;
       var errorName="Can't Delete This Item.";
       alert(errorName);
      console.log('404 Not Found');
    }
    ) ;
    }
}
