import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgxPaginationModule } from 'ngx-pagination';


@NgModule({
  declarations: [
    ChangepasswordComponent,
    DashboardComponent,
    
  ],
  imports: [
    CommonModule,
    BrowserModule,
    NgxPaginationModule
  ]
})
export class DashboardModule { }
