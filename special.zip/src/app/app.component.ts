import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  title = 'Special';
  data: any;
  sData: any;
  finalData: any;
  fullData: any;
  source: any[] = [];

  constructor(private http: HttpClient) {}
  ngOnInit(): void {
    this.http.get('assets/statement-json.json').subscribe((res) => {
      this.data = res;
      // console.log(this.data);

      for (let i = 1; i < this.data.length; i++) {
        this.sData = this.data[i];

        // console.log(this.sData);

        for (let i = 0; i < this.sData.length; i++) {
          this.finalData = this.sData[i];

          if (this.finalData == null) {
            continue;
          }
          if (
            (this.finalData.length == 5 || this.finalData.length == 9) &&
            this.finalData[0] != '' &&
            this.finalData[0] != 'Number' &&
            this.finalData[0] != 'Date'
          ) {
            if (
              this.finalData[0] == '' &&
              this.finalData[1] == '' &&
              this.finalData[2] == '' &&
              this.finalData[3] == '' &&
              this.finalData[4] == ''
            ) {
              continue;
            }
            console.log(this.finalData);
            this.source.push(this.finalData);
          }
        }
      }
    });
  }
}
