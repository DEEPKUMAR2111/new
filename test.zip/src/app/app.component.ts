import { Component, DoCheck } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements DoCheck {
  title = 'Test-4';
  islog=true;
  constructor( private router:Router){  }
  ngDoCheck(): void {
    let currenturl=this.router.url;
    if(currenturl=='/auth/login'||currenturl=='/auth/register'){
  this.islog=false;
    }
    else{
      this.islog=true;
    }
  }
}
