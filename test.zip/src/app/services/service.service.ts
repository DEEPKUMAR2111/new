import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  reg='https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/register';
  log='https://phplaravel-886096-3128455.cloudwaysapps.com/api/v1/login';
  
  constructor( private http:HttpClient) {  }

  errorHandel(error:HttpErrorResponse){  
    return throwError(error.message || 'server Error');
  }

  createPost(post: any){
    return this.http.post(this.reg,post).pipe(catchError(this.errorHandel));
    }

    getId(post:any){
      return this.http.post(this.log,post).pipe(catchError(this.errorHandel));
    }

    isLogin(){
      return localStorage.getItem("arr")!=null;
     }

}