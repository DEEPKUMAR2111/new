import { Router } from '@angular/router';

import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ServiceService } from 'src/app/services/service.service';




@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  userData: any;
  constructor(private router:Router,private service:ServiceService){
    console.log("hello");
    localStorage.clear();
   }

   login= new FormGroup({ 
    email : new FormControl('',[Validators.required,Validators.email]),
    password :new FormControl('',[Validators.required,Validators.minLength(8)]),
  });
  get email(){
    return this.login.get('email');
  }
  get password(){
    return this.login.get('password');
  }

  submit(data:any){
    console.log(data);
    
    var storage:any
    if(this.login.valid){
      this.service.getId(data).subscribe(res=>{
        this.userData=res;
        var token=this.userData.data.a
        console.warn(this.userData.data.data); 
       storage= JSON.stringify(this.userData.data.data);
        localStorage.setItem("arr",storage);
        localStorage.setItem("first_name",this.userData.data.first_name);
        localStorage.setItem("last_name",this.userData.data.last_name);
       this.router.navigate(['/dashboard']);
        }, (error:Response)=>{
        
         var errorName="Can't Find This User.";
       
        console.log('404 Not Found',errorName);
      });
    }}
  
  goTo(){
    this.router.navigate(['auth/register'])
  }
}
  
