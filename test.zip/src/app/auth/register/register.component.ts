

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ServiceService } from 'src/app/services/service.service';



@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  constructor(private router:Router,private service:ServiceService){}
errors: boolean=false;
hide=true;
ngOnInit(): void {
 
  
}

  signup= new FormGroup({ 
    first_name : new FormControl('',[Validators.required]),
    last_name : new FormControl('',[Validators.required]),
    phone_number : new FormControl('',[Validators.required,Validators.minLength(10),Validators.maxLength(10)]),
    email : new FormControl('',[Validators.required,Validators.email]),
    password :new FormControl('',[Validators.required,Validators.minLength(8)]),
    password_confirmation :new FormControl('',[Validators.required,Validators.minLength(8)]),
    subscription_type :new FormControl('1',[Validators.required]),

  });

  get first_name(){
    return this.signup.get('first_name');
  }
  get last_name(){
    return this.signup.get('last_name');
  }
  get phone_number(){
    return this.signup.get('phone_number');
  }
  get email(){
    return this.signup.get('email');
  }
  get password(){
    return this.signup.get('password');
  }
  get password_confirmation(){
    return this.signup.get('password_confirmation');
  }
  get subscription_type(){
    return this.signup.get('terms');
  }

  submit(data:any){
    console.warn(data);
    if(this.signup.invalid){
      this.errors=true;
      console.warn("error");
    }
    else{
    this.service.createPost(data).subscribe(res=>{
      this.router.navigate(['auth/login'])
    }
    );
    }
  }

  goTo(){
    this.router.navigate(['auth/login'])
  }
}
