import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { DashboardComponent } from './dashboard/dashboard.component';


@NgModule({
  declarations: [
    ChangepasswordComponent,
    DashboardComponent
  ],
  imports: [
    CommonModule,
  ]
})
export class DashboardModule { }
