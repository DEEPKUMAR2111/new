import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {

 first:any
 last:any

  constructor(){
     this.first=localStorage.getItem('first_name');
     this.last=localStorage.getItem('last_name');
    console.warn(this.first);
  }
}
