
import { DashboardComponent } from './dashboard/dashboard/dashboard.component';

import { ChangepasswordComponent } from './dashboard/changepassword/changepassword.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from './auth/login/login.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { RegisterComponent } from './auth/register/register.component';
import { AuthGuard } from './gurd/auth.guard';



const routes: Routes = [
  {path:'auth',children:[
    {path:'login', component: LoginComponent },
    {path:'register', component: RegisterComponent},
  ]
},
{path:'dashboard',children:[
   {path:'', component: DashboardComponent,canActivate:[AuthGuard] },
  {path:'changepassword', component: ChangepasswordComponent,canActivate:[AuthGuard] },
]
},
{path:'**', component: NotfoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
