import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { FireServiceService } from '../services/fire-service.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  myTask: any;
hide=true;
  constructor(private router: Router,private service:FireServiceService) { }

  ngOnInit(): void {
  }
  signup= new FormGroup({ 
    first_name : new FormControl('',[Validators.required]),
    last_name : new FormControl('',[Validators.required]),
    phone_number : new FormControl('',[Validators.required,Validators.minLength(10),Validators.maxLength(10)]),
    email : new FormControl('',[Validators.required,Validators.email]),
    password :new FormControl('',[Validators.required,Validators.minLength(8)]),
    id : new FormControl(''),
   
    
  });
  get id(){
    return this.signup.get('id');
  }

  get first_name(){
    return this.signup.get('first_name');
  }
  get last_name(){
    return this.signup.get('last_name');
  }
  get phone_number(){
    return this.signup.get('phone_number');
  }
  get email(){
    return this.signup.get('email');
  }
  get password(){
    return this.signup.get('password');
  }
  
 

  submit(data:any){
    
    if(this.signup.valid){
   this.service.createUser(data);
    this.router.navigate(['/list']);
   this.myTask=data;
 this.service.addTask(this.myTask).then((data)=>{
    console.log(data);
     alert("User Added Successfully");
   });      
    } 
  }

}
