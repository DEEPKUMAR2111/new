import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { FireServiceService } from '../services/fire-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
hide= true;

  constructor(private router: Router,private service:FireServiceService) { }

  ngOnInit(): void {
  }
  login = new FormGroup({
    email: new FormControl("", [Validators.required, Validators.email]),
    password: new FormControl("", [
      Validators.required,
      Validators.minLength(8),
    ]),
  });
  get email() {
    return this.login.get("email");
  }
  get password() {
    return this.login.get("password");
  }

  submit(data: any) {
   
    if (this.login.valid) {
     console.warn(data);
     this.service.loginUser(data.email,data.password)
     this.router.navigate(['/list'])
        }
  }
}
