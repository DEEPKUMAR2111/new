
import { FireServiceService } from './../services/fire-service.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
// import { MatSort } from '@angular/material/sort';

import { MatTableDataSource } from '@angular/material/table';



@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  tasklist:any;
  dataSource:any;
  @ViewChild(MatPaginator) paginator!: MatPaginator ;
  // @ViewChild(MatSort) sort!: MatSort;

  constructor(private service:FireServiceService) { }
Edit=false;
 
  ngOnInit(): void {

    this.service.getTask().subscribe(data=>{
      this.dataSource= new MatTableDataSource(data);
      console.log(this.dataSource)
      this.dataSource.paginator = this.paginator;
    //  this.dataSource.sort = this.sort;
      
     });
     
     

    }
     displayedColumns: string[] = ['first_name', 'last_name', 'email', 'phone_number','edit','delete'];

     delete(data:any){
      this.service.deleteTask(data).then((res)=>{
        alert("Task Deleted Successfully");
      });
      // this.task.reset();
    }

    edit(data:any){
       this.Edit=true;
      // this.currentId=data.id;
      // this.task.setValue(data);
      // this.currentData=data;
    }
  
    
}
