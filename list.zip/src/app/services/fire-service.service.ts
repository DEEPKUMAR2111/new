import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { Firestore, addDoc, collection, collectionData, deleteDoc, doc, updateDoc } from '@angular/fire/firestore';
import { Router } from '@angular/router';
import { Task } from './fire';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FireServiceService {

  constructor(private store:Firestore,private router:Router,private fireAuth:AngularFireAuth) { }

  createUser( data:Task){
    this.fireAuth.createUserWithEmailAndPassword(data.email,data.password).then((res:any)=>{
       localStorage.setItem('user', res.user);
      alert("Registered Successfully.");
      this.router.navigate(['/list']);
    })
  }
  
  loginUser(email:any,password:any){
    this.fireAuth.signInWithEmailAndPassword(email,password).then((res:any)=>{
       localStorage.setItem('token', 'true');
      alert("Login Successfully.");
      this.router.navigate(['/list']);
    })
  }
  
  logOut(){
    this.fireAuth.signOut().then(()=>{
      localStorage.removeItem('token');
      this.router.navigate(['/login']);
    })
  }
  
  addTask(task:Task){
   task.id=doc(collection(this.store,'id')).id
   return addDoc(collection(this.store,'CRUD-App'),task)
  }
  
  getTask():Observable<Task[]>{
    let taskRef=collection(this.store,'CRUD-App')
    return collectionData(taskRef,{idField:'id'}) as Observable<Task[]>
  }
  
  deleteTask(task:Task){
  
    let docRef=doc(collection(this.store,'CRUD-App'),task.id);
    return deleteDoc(docRef)
  }
  
  updateTask(task:Task,tasks:any){
   
    let docRef=doc(collection(this.store,'CRUD-App'),task.id);
    return updateDoc(docRef,tasks)
  }
}
