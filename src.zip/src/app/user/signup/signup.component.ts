import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PopupService } from '@ng-bootstrap/ng-bootstrap/util/popup';
import { ToastrService } from 'ngx-toastr';
import { PostService } from 'src/app/services/post.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  errors: boolean=false;
  countries: {} | undefined;
  states: {} | undefined;
  cities: {} | undefined;
  constructor(private router:Router,private toastr: ToastrService,private service:PostService ){
    sessionStorage.clear();
    this.service.getCountries().subscribe(data => 
      this.countries = data
    );
  }
  signup= new FormGroup({ 
    Username : new FormControl('',[Validators.required]),
    id : new FormControl('',[Validators.required,Validators.email]),
    password :new FormControl('',[Validators.required,Validators.minLength(4)]),
    country: new FormControl(''),
    state: new FormControl(''),
    city: new FormControl(''),
    terms :new FormControl('',[Validators.required]),
  });

  get Username(){
    return this.signup.get('Username');
  }
  get id(){
    return this.signup.get('id');
  }
  get password(){
    return this.signup.get('password');
  }
  get terms(){
    return this.signup.get('terms');
  }
  get country(){
    return this.signup.get('terms');
  }
  get state(){
    return this.signup.get('terms');
  }
  get city(){
    return this.signup.get('terms');
  }

  onChangeCountry(countryId: number) {
    if (countryId) {
      this.service.getStates(countryId).subscribe( data => {
          this.states = data;
          this.cities = "";
        }
      );
    } else {
      this.states = "";
      this.cities = "";
    }
  }

  onChangeState(stateId: number) {
    if (stateId) {
      this.service.getCities(stateId).subscribe(
        data => this.cities = data
      );
    } else {
      this.cities = "";
    }
  }




  submit(data:any){
    console.warn(data);
    if(this.signup.invalid){

      this.errors=true;
      this.toastr.error('Invalid Details');
    }
    else{
    this.toastr.success('Registered Successfully...!');
    this.service.createPost(data).subscribe(res=>{
      this.router.navigate(['user/login'])
    });
    }
  }

  goTo(){
    this.router.navigate(['user/login'])
  }
}
