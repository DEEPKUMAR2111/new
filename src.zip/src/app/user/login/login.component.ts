import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PostService } from 'src/app/services/post.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  userData: any;

constructor(private router:Router,private toastr: ToastrService,private service:PostService){
  sessionStorage.clear();
}

data: any;
showData=false;
errors=false;


submitted=false;
 login= new FormGroup({ 
    email : new FormControl('',[Validators.required,Validators.email]),
    password :new FormControl('',[Validators.required,Validators.minLength(4)]),
  });
  get email(){
    return this.login.get('email');
  }
  get password(){
    return this.login.get('password');
  }


  goTo(){
    this.router.navigate(['user/signup'])
  }

  submit(data:any){
    this.submitted= true;
    this.data=data;
    console.log(this.data); 
    if(this.login.valid){
      this.service.getid(this.login.value.email).toPromise().then(res=>{
        this.userData=res;
        console.warn(this.userData); 
        if(this.userData.password===this.login.value.password){
          sessionStorage.setItem('id',this.userData.id);
          sessionStorage.setItem('username',this.userData.username);
          this.toastr.success('Login Successfully...!');
          this.router.navigate(['/user/data']);
        }
        else{
          this.toastr.error('Password Not Match');
        }
          
      }, (error:Response)=>{
        // this.activeError=true;
         var errorName="Can't Find This User.";
         this.toastr.warning(errorName);
        console.log('404 Not Found');
      });
   
      }
    else{
        this.errors=true;
        this.toastr.error('Invalid Email or Password');  
      }
  }

}
